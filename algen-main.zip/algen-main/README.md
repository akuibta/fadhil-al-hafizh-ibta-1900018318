# algen
Algoritma Genetika
